package com.ecommerce.springBoot.application.dto.Login;

public record LoginUserCommand(
        String email,
        String password
) {}
