package com.ecommerce.springBoot.infrastructure.persistence.JpaRepository.User;

import com.ecommerce.springBoot.domain.models.User;
import com.ecommerce.springBoot.infrastructure.persistence.User.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserJpaRepository extends JpaRepository<UserEntity, String> {
    Optional<UserEntity> findByEmail(String username);
}
