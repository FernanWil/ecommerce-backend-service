package com.ecommerce.springBoot.infrastructure.persistence.User;

import com.ecommerce.springBoot.application.ports.out.User.UserRepositoryPort;
import com.ecommerce.springBoot.domain.models.User;
import com.ecommerce.springBoot.infrastructure.persistence.JpaRepository.User.UserJpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class UserJpaAdapter implements UserRepositoryPort {

    private final UserJpaRepository userJpaRepository;
    public UserJpaAdapter(UserJpaRepository userJpaRepository){
        this.userJpaRepository = userJpaRepository;
    }
    @Override
    public User createUser(User user) {
        UserEntity entity = new UserEntity(user.id(), user.name(), user.email(), user.password());
        UserEntity savedEntity = userJpaRepository.save(entity);
        return new User(savedEntity.getId(), savedEntity.getName(), savedEntity.getEmail(), savedEntity.getPassword());
    }

    @Override
    public Optional<User> findByEmail(String username) {
            return userJpaRepository.findByEmail(username).map(entity -> new User(entity.getId(), entity.getName(), entity.getEmail(), entity.getPassword()));
    }
}
