package com.ecommerce.springBoot.infrastructure.controller.Order;

import com.ecommerce.springBoot.application.dto.Order.CreateOrderCommand;
import com.ecommerce.springBoot.application.dto.Order.OrderLineCommand;
import jakarta.validation.constraints.NotBlank;

import java.util.ArrayList;
import java.util.List;


public record OrderDto (
        @NotBlank(message =  "UserId cannot be blank")
        String userId,
        List<OrderLineDto> items

){
    public CreateOrderCommand toCommand(){
        List<OrderLineCommand> list = new ArrayList<>();
        for (OrderLineDto item: items){
            list.add(new OrderLineCommand(item.productId(),item.quantity()));
        }
        return new CreateOrderCommand(this.userId,list);
    }
}
