package com.ecommerce.springBoot.infrastructure.persistence.JpaRepository.Product;

import com.ecommerce.springBoot.infrastructure.persistence.Product.ProductEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductJpaRepositoryInterface extends JpaRepository<ProductEntity, String> {
}
